
/**
 * Direction.java
 * returns the number from 0-3 
 * Jade Chang
 * CS231 Lab B
 * May 8 2022
 */
public enum Direction {
    NORTH, SOUTH, EAST, WEST
}
